﻿namespace NowApi.ViewModel.Common
{
    public class BaseRequest
    {
        public Guid Id { get; set; }
    }
}
